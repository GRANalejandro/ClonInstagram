import './StoriesItems.css'

const StoriesItem = ()=>{
    return(
        <div className='stories__item'>
            
        </div>
    )
};

export default StoriesItem