import './PostImageItem.css'

const PotsImagesItems = ()=>{
    return(
        <div className="pots__images">

        </div>
    )
};

export default PotsImagesItems