import './StoriesText.css'

const StoriesText = ()=>{
    return(
        <div className='stories--text'>
            <p>Historias destacadas</p>
            <p>Guarda tus historias favoritas en el perfil</p>
        </div>
    )
};

export default StoriesText