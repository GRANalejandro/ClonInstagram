import './Pots.css'
import PotsImages from '../PostImages/PostImage';

const Pots = ()=>{
    return(
        <div className="pots">
            <div className='pots__sections'>
                <div></div>
                <div></div>
                <div></div>
            </div>
            <PotsImages/>
        </div>
    )
};

export default Pots