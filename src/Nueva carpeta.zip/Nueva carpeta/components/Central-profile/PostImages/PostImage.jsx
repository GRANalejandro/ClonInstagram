import './PotsImages.css'

const PotsImages = ()=>{
    return(
        <div className="pots__images">

        </div>
    )
};

export default PotsImages