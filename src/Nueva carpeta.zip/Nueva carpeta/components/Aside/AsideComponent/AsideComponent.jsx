import './AsideComponent.css'

const AsideComponent = ()=>{
    return(
        <>
            <div className="aside__item">
                <p>Jhon_meme19</p>
            </div>
            <div className="aside__item">
                <div></div>
                <div></div>
            </div>
        </>
        
    )
};

export default AsideComponent